from fastapi import APIRouter
from database import db
from datetime import datetime

router = APIRouter()


@router.post("/submit")
def submit_equipment_issue(
    user_id: str,
    equipment_name: str,
    issue_description: str
):

    issue = {
        "user_id": user_id,
        "equipment_name": equipment_name,
        "issue_description": issue_description,
        "status": "Open",
        "date": datetime.now().strftime("%Y-%m-%d"),
        "time": datetime.now().strftime("%H:%M:%S")
    }

    db.equipment_issues.insert_one(issue)

    return {
        "message": "Equipment issue reported successfully",
        "equipment_name": equipment_name,
        "status": "Open"
    }