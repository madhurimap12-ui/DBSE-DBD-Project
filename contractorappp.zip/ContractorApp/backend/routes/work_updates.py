from fastapi import APIRouter
from database import db
from datetime import datetime

router = APIRouter()


@router.post("/submit")
def submit_work_update(
    user_id: str,
    work_description: str,
    progress: int
):

    work_update = {
        "user_id": user_id,
        "work_description": work_description,
        "progress": progress,
        "date": datetime.now().strftime("%Y-%m-%d"),
        "time": datetime.now().strftime("%H:%M:%S")
    }

    db.work_updates.insert_one(work_update)

    return {
        "message": "Work update submitted successfully",
        "user_id": user_id,
        "progress": progress
    }