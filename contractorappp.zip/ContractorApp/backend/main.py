from fastapi import FastAPI

from database import db

from routes.auth import router as auth_router
from routes.projects import router as projects_router
from routes.attendance import router as attendance_router
from routes.work_updates import router as work_updates_router
from routes.material_requests import router as material_requests_router
from routes.equipment_issues import router as equipment_issues_router
from routes.contractor import router as contractor_router


app = FastAPI()


@app.get("/")
def home():

    return {
        "message": "Contractor App Backend is running!"
    }


@app.get("/database-test")
def database_test():

    collections = db.list_collection_names()

    return {
        "message": "MongoDB is connected!",
        "collections": collections
    }


app.include_router(
    auth_router,
    prefix="/auth"
)


app.include_router(
    projects_router,
    prefix="/projects"
)


app.include_router(
    attendance_router,
    prefix="/attendance"
)


app.include_router(
    work_updates_router,
    prefix="/work-updates"
)


app.include_router(
    material_requests_router,
    prefix="/material-requests"
)


app.include_router(
    equipment_issues_router,
    prefix="/equipment-issues"
)


app.include_router(
    contractor_router,
    prefix="/contractor"
)