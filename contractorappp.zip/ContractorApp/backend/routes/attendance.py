from fastapi import APIRouter
from database import db
from datetime import datetime

router = APIRouter()


@router.post("/mark")
def mark_attendance(user_id: str):

    attendance = {
        "user_id": user_id,
        "date": datetime.now().strftime("%Y-%m-%d"),
        "time": datetime.now().strftime("%H:%M:%S"),
        "status": "Present"
    }

    db.attendance.insert_one(attendance)

    return {
        "message": "Attendance marked successfully",
        "user_id": user_id,
        "status": "Present"
    }