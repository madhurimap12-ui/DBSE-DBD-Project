from database import db

users = [
    {
        "user_id": "W001",
        "name": "Rahul",
        "password": "worker123",
        "role": "worker"
    },
    {
        "user_id": "C001",
        "name": "Arun",
        "password": "contractor123",
        "role": "contractor"
    }
]

db.users.delete_many({})

db.users.insert_many(users)

print("Test users created successfully!")