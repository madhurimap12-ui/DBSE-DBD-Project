from fastapi import APIRouter
from database import db

router = APIRouter()


@router.get("/")
def get_projects():

    projects = list(db.projects.find({}, {"_id": 0}))

    return {
        "projects": projects
    }