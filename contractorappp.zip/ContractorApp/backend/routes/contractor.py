from fastapi import APIRouter
from database import db
from datetime import datetime

router = APIRouter()


@router.get("/attendance")
def get_worker_attendance():

    attendance = list(
        db.attendance.find(
            {},
            {"_id": 0}
        ).sort("date", -1)
    )

    return {
        "attendance": attendance
    }


@router.get("/work-updates")
def get_work_updates():

    work_updates = list(
        db.work_updates.find(
            {},
            {"_id": 0}
        ).sort("date", -1)
    )

    return {
        "work_updates": work_updates
    }


@router.get("/material-requests")
def get_material_requests():

    material_requests = list(
        db.material_requests.find(
            {},
            {"_id": 0}
        ).sort("date", -1)
    )

    return {
        "material_requests": material_requests
    }


@router.put("/material-requests/update")
def update_material_request(
    user_id: str,
    material_name: str,
    status: str
):

    if status not in ["Approved", "Rejected"]:
        return {
            "message": "Invalid status"
        }

    result = db.material_requests.update_one(
        {
            "user_id": user_id,
            "material_name": material_name,
            "status": "Pending"
        },
        {
            "$set": {
                "status": status,
                "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
        }
    )

    if result.modified_count > 0:
        return {
            "message": f"Material request {status.lower()} successfully",
            "status": status
        }

    return {
        "message": "Material request not found or already processed"
    }


@router.get("/equipment-issues")
def get_equipment_issues():

    equipment_issues = list(
        db.equipment_issues.find(
            {},
            {"_id": 0}
        ).sort("date", -1)
    )

    return {
        "equipment_issues": equipment_issues
    }


@router.put("/equipment-issues/update")
def update_equipment_issue(
    user_id: str,
    equipment_name: str,
    status: str
):

    if status not in ["Resolved", "Rejected"]:
        return {
            "message": "Invalid status"
        }

    result = db.equipment_issues.update_one(
        {
            "user_id": user_id,
            "equipment_name": equipment_name,
            "status": "Open"
        },
        {
            "$set": {
                "status": status,
                "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
        }
    )

    if result.modified_count > 0:
        return {
            "message": f"Equipment issue {status.lower()} successfully",
            "status": status
        }

    return {
        "message": "Equipment issue not found or already processed"
    }