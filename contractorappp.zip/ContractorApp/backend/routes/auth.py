from fastapi import APIRouter
from database import db

router = APIRouter()


@router.post("/login")
def login(user_id: str, password: str):

    user = db.users.find_one({
        "user_id": user_id,
        "password": password
    })

    if user:
        return {
            "message": "Login successful",
            "user_id": user["user_id"],
            "name": user["name"],
            "role": user["role"]
        }

    return {
        "message": "Invalid user ID or password"
    }