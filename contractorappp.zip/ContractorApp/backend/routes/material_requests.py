from fastapi import APIRouter
from database import db
from datetime import datetime

router = APIRouter()


@router.post("/submit")
def submit_material_request(
    user_id: str,
    material_name: str,
    quantity: int
):

    request = {
        "user_id": user_id,
        "material_name": material_name,
        "quantity": quantity,
        "status": "Pending",
        "date": datetime.now().strftime("%Y-%m-%d"),
        "time": datetime.now().strftime("%H:%M:%S")
    }

    db.material_requests.insert_one(request)

    return {
        "message": "Material request submitted successfully",
        "material_name": material_name,
        "quantity": quantity,
        "status": "Pending"
    }